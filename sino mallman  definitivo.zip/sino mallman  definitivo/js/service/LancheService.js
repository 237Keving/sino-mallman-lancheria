class LancheService {
    constructor() {
        this.storage = new ArmazenamentoService('lanches_db');
        this.lanches = [];
        this.init();
    }

    init() {
        const dadosNoStorage = this.storage.buscar();

        if (dadosNoStorage && dadosNoStorage.length > 0) {
            this.lanches = dadosNoStorage.map(l => 
                new Lanche(l.id, l.nome, l.preco, l.descricao, l.imagem, l.categoria, l.tag)
            );
        } else {
            this.lanches = [
                new Lanche(1, "X-Bacon Supremo", 38.90, "Pão brioche, blend 180g e bacon crocante.", "assets/img/x-bacon.png", "Hambúrgueres", "🔥 Mais Pedido"),
                new Lanche(2, "Combo Sino Mallman", 55.00, "O clássico burger da casa com batata e refri.", "assets/img/combo-sino.png", "Combos", "⭐ Destaque")
            ];
            this.storage.salvar(this.lanches);
        }
    }

    getAll() {
        return this.lanches;
    }

    getById(id) {
        return this.lanches.find(l => Number(l.id) === Number(id));
    }

    save(lanche) {
        const index = this.lanches.findIndex(l => Number(l.id) === Number(lanche.id));

        if (index !== -1) {
            this.lanches[index] = lanche;
        } else {
            if (!lanche.id || lanche.id === 0) {
                lanche.id = Date.now();
            }
            this.lanches.push(lanche);
        }

        this.storage.salvar(this.lanches);
    }

    delete(id) {
        this.lanches = this.lanches.filter(l => Number(l.id) !== Number(id));
        this.storage.salvar(this.lanches);
    }
}