class LancheController {
    constructor(service, view) {
        this.service = service;
        this.view = view;
        this.init();
    }

    init() {
        this.view.bindSalvar(() => this.handleSave());
        this.view.bindEditar((id) => this.handleEdit(id));
        this.view.bindExcluir((id) => this.handleDelete(id));
    }

    exibirCardapio() {
        const lanches = this.service.getAll();
        if (lanches) {
            this.view.renderizarCardapio(lanches);
        }
    }

    handleSave() {
        const data = this.view.getFormData();
        
        if (!data.nome || !data.preco) {
            alert("Por favor, preencha os campos obrigatórios.");
            return;
        }

        const lancheObjeto = new Lanche(
            data.id || Date.now(), 
            data.nome, 
            parseFloat(data.preco), 
            data.descricao, 
            data.imagem, 
            data.categoria, 
            data.tag
        );

        this.service.save(lancheObjeto);
        this.view.clearForm();
        this.refresh();
    }

    handleEdit(id) {
        const lanche = this.service.getById(id);
        if (lanche) {
            this.view.fillForm(lanche);
        }
    }

    handleDelete(id) {
        if (confirm("Tem certeza que deseja remover este lanche do cardápio?")) {
            this.service.delete(id);
            this.refresh();
        }
    }

    refresh() {
        const dados = this.service.getAll();
        
        if (typeof this.view.renderizarCardapio === 'function') {
            this.view.renderizarCardapio(dados);
        }
        
        if (typeof this.view.renderList === 'function') {
            this.view.renderList(dados);
        }
    }
}