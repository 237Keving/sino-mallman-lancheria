class MenuView {
    constructor() {
        this.paoTopo = document.getElementById('pao-topo');
        this.alface = document.getElementById('alface');
        this.cebola = document.getElementById('cebola');
        this.tomate = document.getElementById('tomate');
        this.queijo = document.getElementById('queijo');
        this.carne = document.getElementById('carne');
        this.paoBase = document.getElementById('pao-base');
    }

    bindScroll(callback) {
        window.addEventListener('scroll', () => {
            callback(window.scrollY);
        });
    }

    animarBurger(scroll) {
        const f = scroll * 0.3;

        if (this.paoTopo) this.paoTopo.style.transform = `translateY(${-65 + (f * 1.5)}px)`;
        if (this.alface)   this.alface.style.transform = `translateY(${-45 + (f * 1.2)}px)`;
        if (this.cebola)   this.cebola.style.transform = `translateY(${-35 + (f * 1.0)}px)`;
        if (this.tomate)   this.tomate.style.transform = `translateY(${-25 + (f * 0.8)}px)`;
        if (this.queijo)   this.queijo.style.transform = `translateY(${-15 + (f * 0.6)}px)`;
        if (this.carne)    this.carne.style.transform = `translateY(${-10 + (f * 0.4)}px)`;
        if (this.paoBase)  this.paoBase.style.transform = `translateY(${10 + (f * 0.1)}px)`;
    }
}