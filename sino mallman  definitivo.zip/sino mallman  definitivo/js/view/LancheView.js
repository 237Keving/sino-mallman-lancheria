class LancheView {
    constructor() {
        this.gridCardapio = document.querySelector('.conteudo-cardapio');
        this.containerLista = document.getElementById("lancheList");
        this.form = document.getElementById('formLanche');
        this.formInputs = {
            id: document.getElementById('id'),
            nome: document.getElementById('nome'),
            preco: document.getElementById('preco'),
            descricao: document.getElementById('descricao'),
            imagem: document.getElementById('imagem'),
            categoria: document.getElementById('categoria'),
            tag: document.getElementById('tag')
        };
    }

    bindSalvar(handler) {
        const btn = document.getElementById('btnSave');
        if (btn) {
            btn.addEventListener('click', (e) => {
                e.preventDefault();
                handler();
            });
        }
    }

    bindEditar(handler) {
        if (!this.containerLista) return;
        this.containerLista.addEventListener('click', e => {
            const btn = e.target.closest('.btn-edit-adm');
            if (btn) handler(btn.dataset.id);
        });
    }

    bindExcluir(handler) {
        if (!this.containerLista) return;
        this.containerLista.addEventListener('click', e => {
            const btn = e.target.closest('.btn-delete-adm');
            if (btn) handler(btn.dataset.id);
        });
    }

    getFormData() {
        return {
            id: parseInt(this.formInputs.id.value) || 0,
            nome: this.formInputs.nome.value,
            preco: parseFloat(this.formInputs.preco.value) || 0,
            descricao: this.formInputs.descricao.value,
            imagem: this.formInputs.imagem.value,
            categoria: this.formInputs.categoria.value,
            tag: this.formInputs.tag.value
        };
    }

    fillForm(lanche) {
        if (!this.formInputs.id) return;
        this.formInputs.id.value = lanche.id;
        this.formInputs.nome.value = lanche.nome;
        this.formInputs.preco.value = lanche.preco;
        this.formInputs.descricao.value = lanche.descricao;
        this.formInputs.imagem.value = lanche.imagem;
        this.formInputs.categoria.value = lanche.categoria;
        this.formInputs.tag.value = lanche.tag;
        window.scrollTo({ top: 0, behavior: 'smooth' });
    }

    clearForm() {
        if (this.form) this.form.reset();
        if (this.formInputs.id) this.formInputs.id.value = 0;
    }

    renderizarCardapio(lista) {
        if (!this.gridCardapio) return;
        
        this.gridCardapio.innerHTML = `
            <div class="secao-titulo">
                <h2>🍔 Nosso Cardápio</h2>
                <p>Produtos selecionados com o padrão Sino Mallman</p>
            </div>
            <div class="cardapio-grid"></div>
        `;

        const grid = this.gridCardapio.querySelector('.cardapio-grid');

        lista.forEach(item => {
            const tagHtml = item.tag ? `<span class="tag-produto">${item.tag}</span>` : '';
            
            grid.innerHTML += `
                <article class="produto-card" data-id="${item.id}" style="cursor: pointer" onclick="window.location.href='produto.html?id=${item.id}'">
                    <div class="card-thumb">
                        ${tagHtml}
                        <img src="${item.imagem}" alt="${item.nome}" onerror="this.src='assets/img/placeholder-burger.png'">
                    </div>
                    <div class="card-info">
                        <h3>${item.nome}</h3>
                        <p>${item.descricao}</p>
                        <div class="card-footer">
                            <span class="preco">R$ ${parseFloat(item.preco).toFixed(2)}</span>
                            <span class="material-symbols-outlined add-icon">add_circle</span>
                        </div>
                    </div>
                </article>`;
        });
    }

    renderList(lanches) {
        if (!this.containerLista) return;
        this.containerLista.innerHTML = "";

        lanches.forEach(l => {
            const row = document.createElement("div");
            row.className = "item-lista-adm";
            row.innerHTML = `
                <div class="item-info">
                    <img src="${l.imagem}" alt="">
                    <div>
                        <strong>${l.nome}</strong>
                        <span>R$ ${parseFloat(l.preco).toFixed(2)}</span>
                    </div>
                </div>
                <div class="item-acoes">
                    <button class="btn-edit-adm" data-id="${l.id}">
                        <span class="material-symbols-outlined">edit</span>
                    </button>
                    <button class="btn-delete-adm" data-id="${l.id}">
                        <span class="material-symbols-outlined">delete</span>
                    </button>
                </div>
            `;
            this.containerLista.appendChild(row);
        });
    }
}