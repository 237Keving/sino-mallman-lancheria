class AdmView {
    constructor() {
        this.form = document.getElementById('formLanche');
        this.inputId = document.getElementById('id');
        this.inputNome = document.getElementById('nome');
        this.inputPreco = document.getElementById('preco');
        this.inputDescricao = document.getElementById('descricao');
        this.inputImagem = document.getElementById('imagem');
        this.inputCategoria = document.getElementById('categoria');
        this.inputTag = document.getElementById('tag');
        this.tabelaCorpo = document.getElementById('lancheList');
    }

    bindSalvar(handler) {
        const btn = document.getElementById('btnSave');
        if (btn) {
            btn.addEventListener('click', (e) => {
                e.preventDefault();
                handler();
            });
        }
    }

    getFormData() {
        return {
            id: parseInt(this.inputId.value) || 0,
            nome: this.inputNome.value,
            preco: parseFloat(this.inputPreco.value) || 0,
            descricao: this.inputDescricao.value,
            imagem: this.inputImagem.value,
            categoria: this.inputCategoria.value,
            tag: this.inputTag.value
        };
    }

    fillForm(lanche) {
        this.inputId.value = lanche.id;
        this.inputNome.value = lanche.nome;
        this.inputPreco.value = lanche.preco;
        this.inputDescricao.value = lanche.descricao;
        this.inputImagem.value = lanche.imagem;
        this.inputCategoria.value = lanche.categoria;
        this.inputTag.value = lanche.tag;
    }

    clearForm() {
        this.inputId.value = 0;
        this.inputNome.value = '';
        this.inputPreco.value = '';
        this.inputDescricao.value = '';
        this.inputImagem.value = '';
        this.inputCategoria.value = '';
        this.inputTag.value = '';
    }

    renderList(lanches) {
        if (!this.tabelaCorpo) return;
        this.tabelaCorpo.innerHTML = '';

        lanches.forEach(l => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td>${l.id}</td>
                <td>${l.nome}</td>
                <td>R$ ${l.preco.toFixed(2)}</td>
                <td>${l.categoria}</td>
                <td>
                    <button onclick="controller.edit(${l.id})">Editar</button>
                    <button onclick="controller.delete(${l.id})">Excluir</button>
                </td>
            `;
            this.tabelaCorpo.appendChild(tr);
        });
    }
}