class Lanche {
    constructor(id, nome, preco, descricao, imagem, categoria, tag) {
        this.id = Number(id);
        this.nome = nome;
        this.preco = Number(preco);
        this.descricao = descricao;
        this.imagem = imagem;
        this.categoria = categoria;
        this.tag = tag; 
    }
}