class ArmazenamentoService {
    constructor(chave) {
        this.chave = chave;
    }

    salvar(dados) {
        try {
            const json = JSON.stringify(dados);
            localStorage.setItem(this.chave, json);
            return true;
        } catch (erro) {
            return false;
        }
    }

    buscar() {
        try {
            const dados = localStorage.getItem(this.chave);
            return dados ? JSON.parse(dados) : [];
        } catch (erro) {
            return [];
        }
    }

    limpar() {
        try {
            localStorage.removeItem(this.chave);
            return true;
        } catch (erro) {
            return false;
        }
    }
}