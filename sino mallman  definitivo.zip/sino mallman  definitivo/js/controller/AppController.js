class AppController {
    constructor(view) {
        this.view = view;
        this.init();
    }

    init() {
        this.view.bindScroll((valor) => this.atualizarLayout(valor));
    }

    atualizarLayout(scroll) {
        this.view.animarBurger(scroll);
    }
}